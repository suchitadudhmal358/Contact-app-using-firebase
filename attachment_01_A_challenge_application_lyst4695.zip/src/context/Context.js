//TODO: Create context: ContactContext
